#' Get parameters and residuals from the NULL model
#'
#' Compute model parameters and residuals for Phenome-Wide Interaction Studies (PheWIS).
#' @param formula an object of class “formula”: a symbolic description of the Covariates-Only model to be fitted. See details section of help(PheWIS).
#' @param data an optional data frame containing the variables in the model (default=NULL). If it is NULL, the variables are taken from 'environment(formula)'
#' @param out_type an indicator of the outcome type. "D" for the dichotomous outcome.
#' @return This function returns an object that has model parameters and residuals of the model to fit outcome and covariates only. After obtaining it, please use PheWIS() function to conduct the association test.
#' @examples
#' Data.ls = data.simu.null(N = 1000, nSNP = 10, nCov = 2, maf = 0.3, prev = 0.1)
#' Phen.mtx = Data.ls$Phen.mtx
#' obj.null = PheWIS_Null_Model(y~Cov1+Cov2, data=Phen.mtx, out_type="D")
#' @export
PheWIS_Null_Model = function(formula,
                             data=NULL,
                             out_type="D")
{
  check.outType(out_type)
  if(out_type=="D")
    res.glm = glm(formula, data, family=binomial)

  mu = res.glm$fitted.values  # the fitted mean values, obtained by transforming the linear predictors by the inverse of the link function.
  coef = res.glm$coefficients
  W = (1-mu)*mu
  X = model.matrix(res.glm)   # Design matrix
  WX = W*X
  XWX_inv = solve(t(X)%*%WX)           # inverse matrix of (X %*% W %*% X)

  XW = t(WX)
  y = res.glm$y
  XXWX_inv = X %*% XWX_inv

  obj.null = list(mu=mu, W=W, coef=coef, y=y, XW=XW, XXWX_inv = XXWX_inv, y.mu=y-mu, X=X)
  class(obj.null) = "PheWIS_Null_Model"

  return(obj.null)
}

#### Check OutType
check.outType = function(out_type)
{
  # if (out_type != "C" && out_type != "D") {
  #   stop("Invalid out_type!. Please use either \"C\" for the continous outcome or \"D\" for the dichotomous outcome.")
  # }
  if (out_type != "D") {
    stop("Invalid out_type!. Please use \"D\" for the dichotomous outcome.")
  }
}


